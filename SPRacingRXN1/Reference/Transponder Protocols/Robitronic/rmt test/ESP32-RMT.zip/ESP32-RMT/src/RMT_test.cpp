// The RMT (Remote Control) module library is used for generating the DShot signal.
//#include <driver/rmt.h>
//rmt_tx_config_t xxx;

#include "Arduino.h"
#include "esp32-hal-rmt.h"

const uint8_t GPIO_PIN = 48;        // use arbitrary GPIO

const uint8_t NUMBER_OF_BITS = 16;  // number of bits in bitstream
uint16_t bitStream = 0x55AA;        // let this be the bitstream

rmt_data_t rmtBits[NUMBER_OF_BITS]; // space for rmt data
rmt_obj_t *rmtObjPtr;               // pointer to the rmt object

void setup() {
  Serial.begin(115200);

  // initialize rmt as output on selected GPIO pin
  rmtObjPtr = rmtInit(GPIO_PIN, RMT_TX_MODE, RMT_MEM_256);

  if(rmtObjPtr == nullptr)
    Serial.println("init sender failed\n");

  // try to set tick period to 1000ns    
  float realTick = rmtSetTick(rmtObjPtr, 1000.0);

  Serial.print("real tick set to: "); 
  Serial.print(realTick);
  Serial.println("ns");

  // dump rmt status
  _rmtDumpStatus(rmtObjPtr);

  //
  // prepare rmt encoded data for bitstream
  //
	uint16_t mask = 0x8000;

	for(uint8_t i = 0; i < NUMBER_OF_BITS; i++) {
		if(bitStream & mask) {
      // encode 1: 2us on, 8us off
      rmtBits[i].level0 = 1;
      rmtBits[i].duration0 = 2;
      rmtBits[i].level1 = 0;
      rmtBits[i].duration1 = 8;
    } else {
      // encode 0: 10us off
      rmtBits[i].level0 = 1;
      rmtBits[i].duration0 = 0;
      rmtBits[i].level1 = 0;
      rmtBits[i].duration1 = 10;
    }

    mask >>= 1;
  }
}

void loop() {
  // trigger rmt transmission
  rmtWrite(rmtObjPtr, rmtBits, NUMBER_OF_BITS);

  // do it every 4ms
  delay(4);
}